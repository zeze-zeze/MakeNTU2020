# ChangeLog

## [0.0.1] - 2020-04-24
### Added
- pixetto.py: Pixetto class for vision sensor.
- example.py: sample code to read data.
- COPYING
- CHANGELOG.md
- README.md
