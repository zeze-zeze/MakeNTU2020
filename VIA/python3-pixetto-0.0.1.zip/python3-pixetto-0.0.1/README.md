# Pixetto library for Python3

Use Pixetto library to read data from VIA Pixetto vision sensor.
